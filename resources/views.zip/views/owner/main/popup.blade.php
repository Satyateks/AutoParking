@extends('components.owner.main')

@section('main-container')

<H1>Your Kyc form is summited successfull , please wait for approval</H1>

@endsection()
