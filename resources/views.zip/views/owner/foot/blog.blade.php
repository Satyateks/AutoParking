@extends('components.user.main')
@section('main-container')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="blog-column">
                <img src="images/coming_soon.gif" alt="">
            </div>
        </div>
    </div>
</div>

   @endsection()
