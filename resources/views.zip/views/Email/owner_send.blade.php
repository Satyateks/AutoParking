<a href="{{ url('onwer_password_update',$token)}}" >reset password</a>
